#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
using namespace std;
string empid, fname, lname, date, phone, maritial_status, depname;
int edeptid, salary,depid;
void highest_salary_employee()
{
	ifstream fin;
	string hname;
	fin.open("emp.csv");
	if (fin.is_open()) {
		string line;
		int max = 0;
		while (getline(fin, line)) {
			stringstream ss(line);
			getline(ss, empid, ',');
			getline(ss, fname, ',');
			getline(ss, lname, ',');
			getline(ss, date, ',');
			ss >> edeptid;
			ss.ignore(1, ',');
			getline(ss, phone, ',');
			ss >> salary;
			if (salary > max) {
				max = salary;
				hname = fname+" "+lname;
			}
			getline(ss, maritial_status, ',');

		}
		fin.close();
		cout << "\nHighest salary is of "<<hname<<" : " << max << endl;
	}
	else {
		cout << "\nFile not found" << endl;
	}
}
void lowest_salary() {
	ifstream fin;
	string hname;
	fin.open("emp.csv");
	if (fin.is_open()) {
		string line;
		int min = 1000000;
		while (getline(fin, line)) {
			stringstream ss(line);
			getline(ss, empid, ',');
			getline(ss, fname, ',');
			getline(ss, lname, ',');
			getline(ss, date, ',');
			ss >> edeptid;
			ss.ignore(1, ',');
			getline(ss, phone, ',');
			ss >> salary;
			if (salary < min) {
				min = salary;
				hname = fname + " " + lname;
			}
			getline(ss, maritial_status, ',');

		}
		fin.close();
		cout << "\nMinimum salary is of " << hname << " : " << min << endl;
	}
	else {
		cout << "File not found" << endl;
	}
}
void marriedEmployees() {
	ifstream fin;
	fin.open("emp.csv");
	int count = 0;
	if (fin.is_open())
	{
		string line;
		while (getline(fin, line)) {
			stringstream ss(line);
			getline(ss, empid, ',');
			getline(ss, fname, ',');
			getline(ss, lname, ',');
			getline(ss, date, ',');
			ss >> edeptid;
			ss.ignore(1, ',');
			getline(ss, phone, ',');
			ss >> salary;
			ss.ignore(1, ',');
			getline(ss, maritial_status, ',');
			if (maritial_status == "Married") {
				count++;
			}
		}
		fin.close();
		cout << "\nTotal married employees are : " << count;
	}
	else {
		cout << "\nunable to open file.";
	}
}
void singleEmployees() {
	ifstream fin;
	fin.open("emp.csv");
	int count = 0;
	if (fin.is_open())
	{
		string line;
		while (getline(fin, line)) {
			stringstream ss(line);
			getline(ss, empid, ',');
			getline(ss, fname, ',');
			getline(ss, lname, ',');
			getline(ss, date, ',');
			ss >> edeptid;
			ss.ignore(1, ',');
			getline(ss, phone, ',');
			ss >> salary;
			ss.ignore(1, ',');
			getline(ss, maritial_status, ',');
			if (maritial_status != "Married") {
				count++;
			}
		}
		fin.close();
		cout << "\nTotal single employees are : " << count;
	}
	else {
		cout << "\nunable to open file.";
	}
}
void averageSalary() {
	ifstream fin;
	fin.open("emp.csv");
	int count = 0,total=0, avg = 0;;
	if (fin.is_open())
	{
		string line;
		while (getline(fin, line)) {
			stringstream ss(line);
			getline(ss, empid, ',');
			getline(ss, fname, ',');
			getline(ss, lname, ',');
			getline(ss, date, ',');
			ss >> edeptid;
			ss.ignore(1, ',');
			getline(ss, phone, ',');
			ss >> salary;
			ss.ignore(1, ',');
			getline(ss, maritial_status, ',');
			total = total + salary;
			count++;
		}
		fin.close();
		cout << "\nAverage salary of employee is : " << float(total/count);
	}
	else {
		cout << "\nunable to open file.";
	}
}
void higherSalaryThanDianaRoss() {
	ifstream fin;
	fin.open("emp.csv");
	int count = 0;
	int dsalary = 0;
	bool chk = true;
	if (fin.is_open())
	{
		string line;
		while (getline(fin, line)) {
			stringstream ss(line);
			getline(ss, empid, ',');
			getline(ss, fname, ',');
			getline(ss, lname, ',');
			getline(ss, date, ',');
			ss >> edeptid;
			ss.ignore(1, ',');
			getline(ss, phone, ',');
			ss >> salary;
			ss.ignore(1, ',');
			getline(ss, maritial_status, ',');
			if (fname == "Diana"&&lname=="Ross") {
				dsalary = salary;
				count++;
				cout << "\nSalary of Diana Ross is : " << dsalary;
				break;
			}
		}
		fin.clear();
		fin.seekg(0, ios::beg);
		cout << "\nemployees with higher slaries than that of Diana Ross are : ";
		while (getline(fin, line)) {
			stringstream ss(line);
			getline(ss, empid, ',');
			getline(ss, fname, ',');
			getline(ss, lname, ',');
			getline(ss, date, ',');
			ss >> edeptid;
			ss.ignore(1, ',');
			getline(ss, phone, ',');
			ss >> salary;
			ss.ignore(1, ',');
			getline(ss, maritial_status, ',');
			if (salary > dsalary)
			{
				cout << "\n" << fname << " " << lname;
				chk = false;
			}
		}
		fin.close();
		if (chk) {
			cout << "\nNo employee has higher salary than Diana Ross";
		}
	}
	else {
		cout << "\nunable to open file.";
	}
}
void higherSalaryThanEthenBrown() {
	ifstream fin;
	fin.open("emp.csv");
	int count = 0;
	int dsalary = 0;
	bool chk = true;
	if (fin.is_open())
	{
		string line;
		while (getline(fin, line)) {
			stringstream ss(line);
			getline(ss, empid, ',');
			getline(ss, fname, ',');
			getline(ss, lname, ',');
			getline(ss, date, ',');
			ss >> edeptid;
			ss.ignore(1, ',');
			getline(ss, phone, ',');
			ss >> salary;
			ss.ignore(1, ',');
			getline(ss, maritial_status, ',');
			if (fname == "Ethan" && lname == "Brown") {
				dsalary = salary;
				count++;
				cout << "\nSalary of Ethen Brown is : " << dsalary;
				break;
			}
		}
		fin.clear();
		fin.seekg(0, ios::beg);
		cout << "\nemployees with higher slaries than that of Ethen Brown are : ";
		while (getline(fin, line)) {
			stringstream ss(line);
			getline(ss, empid, ',');
			getline(ss, fname, ',');
			getline(ss, lname, ',');
			getline(ss, date, ',');
			ss >> edeptid;
			ss.ignore(1, ',');
			getline(ss, phone, ',');
			ss >> salary;
			ss.ignore(1, ',');
			getline(ss, maritial_status, ',');
			if (salary > dsalary)
			{
				cout << "\n" << fname << " " << lname;
				chk = false;
			}
		}
		fin.close();
		if (chk) {
			cout << "\nNo employee has higher salary than Ethen Brown";
		}
	}
	else {
		cout << "\nunable to open file.";
	}
}
void higherSalaryThanCharlieDavis() {
	ifstream fin;
	fin.open("emp.csv");
	int count = 0;
	int dsalary = 0;
	bool chk = true;
	if (fin.is_open())
	{
		string line;
		while (getline(fin, line)) {
			stringstream ss(line);
			getline(ss, empid, ',');
			getline(ss, fname, ',');
			getline(ss, lname, ',');
			getline(ss, date, ',');
			ss >> edeptid;
			ss.ignore(1, ',');
			getline(ss, phone, ',');
			ss >> salary;
			ss.ignore(1, ',');
			getline(ss, maritial_status, ',');
			if (fname == "Charlie" && lname == "Davis") {
				dsalary = salary;
				count++;
				cout << "\nSalary of Charlie Davis is : " << dsalary;
				break;
			}
		}
		fin.clear();
		fin.seekg(0, ios::beg);
		cout << "\nemployees with higher slaries than that of Charlie Davis are : ";
		while (getline(fin, line)) {
			stringstream ss(line);
			getline(ss, empid, ',');
			getline(ss, fname, ',');
			getline(ss, lname, ',');
			getline(ss, date, ',');
			ss >> edeptid;
			ss.ignore(1, ',');
			getline(ss, phone, ',');
			ss >> salary;
			ss.ignore(1, ',');
			getline(ss, maritial_status, ',');
			if (salary > dsalary)
			{
				cout << "\n" << fname << " " << lname;
				chk = false;
			}
		}
		fin.close();
		if (chk) {
			cout << "\nNo employee has higher salary than Charlie Davis";
		}
	}
	else {
		cout << "\nunable to open file.";
	}
}

int main() {
	
	highest_salary_employee();
	cout << "\n\n";
	lowest_salary();
	cout << "\n\n";
	marriedEmployees();
	cout << "\n\n";
	singleEmployees();
	cout << "\n\n";
	averageSalary();
	cout << "\n\n";
	higherSalaryThanDianaRoss();
	cout << "\n\n";
	higherSalaryThanCharlieDavis();
	cout << "\n\n";
	higherSalaryThanEthenBrown();
	cout << "\n\n";
	return 0;
}