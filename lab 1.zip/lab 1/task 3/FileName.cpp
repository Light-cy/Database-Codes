#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int main() {
	string empid, fname, lname, date, phone, maritial_status,depname;
	int edeptid, depid, salary;
	ifstream fin1, fin2;
	fin1.open("dept.csv");
	fin2.open("employee.csv");
	while (!fin1.eof()) {
		char trash;
		fin1 >> depid;
		fin1 >> trash;
		fin1 >> depname;
		if (depname == "Sales") {
			fin1.close();
			break;
		}
		
	}
	while (!fin2.eof()) {
		char trash;
		getline(fin2,empid, ',');
		getline(fin2, fname, ',');
		getline(fin2, lname, ',');
		getline(fin2, date, ',');
		fin2 >> edeptid >> trash;
		fin2.ignore();
		getline(fin2, phone, ',');
		fin2 >> salary >> trash;
		fin2 >> maritial_status;
		if (edeptid == depid) {
			cout << fname << " " << lname << "\n";
		}
		
	}
	fin2.close();
	
	
}