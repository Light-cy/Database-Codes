#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int main() {
	string fname, roll, lname, phone, program;
	float cgpa;
	char trash;
	ifstream fin;
	ofstream fout;
	fout.open("new.csv");
	if (fout.is_open()) {
		fout << "L1f11BSCS0001,Sadia,Khan,BSCS,3.27,03321234123\n";
		fout << "L1f11BSCS0021,Shanya,Khan,BSCS,3.77,03321234213\n";
		fout << "L1f11BSCS0031,Goree,Khan,BSCS,3.57,03321234143\n";
		fout << "L1f11BSCS0041,Jemayma,Khan,BSCS,3.85,03321234223\n";
		fout << "L1f11BSCS0022,Samandar,Khan,BSCS,3.97,03321234542\n";
		fout.close();
		fin.open("new.csv");
		while (!fin.eof()) {
			getline(fin, roll, ',');
			getline(fin, fname, ',');
			getline(fin, lname, ',');
			getline(fin, program, ',');
			fin >> cgpa;
			fin >> trash;
			getline(fin, phone, '\n');
			if (cgpa > 2.5 && cgpa <= 3.5) {
				cout << fname << " " << lname << "\n";
			}
		}
	}
	else {
		cout << "\nerror opening file!!";

	}


}